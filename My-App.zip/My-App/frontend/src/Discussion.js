import React from "react";
import "./Discussion.css";
import swal from 'sweetalert';
import { Button, TextField, Link } from '@material-ui/core';
const axios = require('axios');
const bcrypt = require('bcryptjs');
var salt = bcrypt.genSaltSync(10);

class Discussion extends React.Component {

  Control = () => {
    axios.post('http://localhost:2000/discussion', {
      username: localStorage.getItem('user_id'),
      password: localStorage.getItem('token'),
    }).catch((err) => {
      if (err.response && err.response.data && err.response.data.errorMessage) {
        swal({
          text: err.response.data.errorMessage,
          icon: "error",
          type: "error"
        });
      }
    });
  }
 

  SignUp = () => {
    this.setState({ isSign: true });
  };

  render() {

    return (
      <html>
          <body>

      <div id = "background">
      <div class = "center">
      <h3>Project Road-blocks Discussion</h3>
      <div class="container">
  <img id = "img1" src="https://cdn4.iconfinder.com/data/icons/avatars-21/512/avatar-circle-human-male-3-512.png" alt="Avatar"/>
  <p>Hi Team,<br/>
      I am trying to test a sql script. i have broken it out and I am just trying to get this part working. 
      I am getting errors at my update part at the ' + @FieldName + ' . 
      <br/>What do I have to put there to get passed the error</p>
  <span class="time-right">11:00</span>
</div>

<div class="container darker">
  <img img id = "img1" src="https://cdn4.iconfinder.com/data/icons/avatars-21/512/avatar-circle-human-female-5-512.png" alt="Avatar" class="right"/>
  <p>Can you explain what are you trying to do?
  <br/>
Post a few data samples to help us to understand.</p>
  <span class="time-left">11:01</span>
</div>

<div class="container">
  <img id = "img1" src="https://cdn4.iconfinder.com/data/icons/avatars-21/512/avatar-circle-human-male-3-512.png" alt="Avatar"/>
  <p>I am trying to find a certain string in a table and replace it with another string from another table.
  <br/>
ya I saw that and have it in thanks.
<br/>
is on this line I think thats causing an error
SET @FieldName = REPLACE(' @FieldName ',' + @Quote + @StringToFind + @Quote + ',' + @Quote + @StringReplacement + @Quote + ')
</p>
  <span class="time-right">11:02</span>
</div>

<div class="container darker">
  <img id = "img1" src="https://cdn4.iconfinder.com/data/icons/avatars-21/512/avatar-circle-human-male-black-7-512.png" alt="Avatar" class="right"/>
  <p>Anyone any ideas why this is happening. 
      <br/>
      After fixing this error, We will go on a break ! Who wants to join guys
  </p>
  <span class="time-left">11:05</span>
</div>

<Button class="open-button" onClick={this.Control}> Join Discussion</Button>


<div class="chat-popup" id="myForm">
  <form class="form-container">
    <h1>Chat</h1>

    <label for="msg"><b>Message</b></label>
    <textarea placeholder="Type message.." name="msg" required></textarea>

    <button type="submit" class="btn">Send</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>
      </div>
      </div>
      </body>
      </html>
    );
  }
}

export default Discussion;
