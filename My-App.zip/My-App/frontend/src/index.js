import React from 'react';
import ReactDOM from 'react-dom';
import { Switch, Redirect, Route } from 'react-router';
import { BrowserRouter, Link } from 'react-router-dom';

import Login from './Login';
import Register from './Register';
import Discussion from './Discussion';
import './Login.css';

ReactDOM.render(
    <BrowserRouter>



    <div>
            <div class = "nav">
            <ul>
              <li id = "lin" class = "lin1"> 
                <Link to="/">Discussion</Link>
              </li>
              <li id = "lin" class = "lin2">
                <Link to="/Login">Login</Link>
              </li>
              <li id = "lin" class = "lin3">
                <Link to="/Register">Signup</Link>
              </li>
            </ul>
            </div>
            <Switch>
              
              <Route exact path="/" component={Discussion} />
               <Route exact path="/Login" component={Login} />
               <Route exact path="/Register" component={Register} />
            </Switch>
          </div>
    </BrowserRouter>,
    document.getElementById('root')
);